// For AF - Mods Tasks Framework
class Main {
    title = "Misja o koniu co miał walenie"; // Tytuł zadania
    description = "Koń i walenie. To musi się udać"; // Opis zadania. Nie można używać enterów, jeżeli są potrzebne użyj stringtable.xml.
    icon = "takeoff"; // Ikona zadania z https://community.bistudio.com/wiki/Arma_3_Tasks_Overhaul#Appendix

    
    // Cztery warunki zakończenia zadania głównego, czyli misji
    conditionEventsSuccess[] = {"Killed", "Boom", "Intel_1_Found", "Controlled"};
    conditionEventsSuccessRequired = 4;
    
    // Warunek uznania zadania za niezaliczone
    conditionEventsFailed[] = {"playerDied"};
    conditionEventsFailedRequired = 1;
    
    // Gdy zadanie się zaliczy to odpali taki event
    onSuccessEvents[] = { "MissionEnd" };
};

// Dowiedz się czegoś z intelu. Reszta kodu w initPlayerLocal.sqf
class Intel1 {
    title = "Coś tam znajdź"
    icon = "search";
    
    // Zadanie będzie umieszczone na liście zadań jako podzadanie wskazanego zadania.
    parentTask = "Main";
    
    // Pierwszy z 3 sposobów ustawiania znacznika zadania na mapie.
    // Pobrana zostanie pozycja markera o wskazanej nazwie.
    marker = "lezak";
    
	// Ten event definiowany jest w pliku initPlayerLocal.sqf
    conditionEventsSuccess[] = { "Intel_1_Found" };
    
    onSuccessEvents[] = { "IntelFound" };
};

//Znajdź cel - po zbliżeniu się na mniej niż 100m cel zostaje zaliczony
class FindVIP {
    title = "Znajdź VIPA";
    description = "Gdzieś się chowa ten watażka";
    icon = "search";
    parentTask = "Intel1";
    
    // Drugi z 3 sposobów ustawiania znacznika zadania na mapie.
    // Najgorszy, ale dostępny.
    position[] = { 4622, 9689 };

    conditionEventsShow[] = { "IntelFound" };
    conditionEventsShowRequired = 1;
    
    // Kod, który musi zwrócić true, żeby zadanie zostało zaliczone
    // Sprawdza czy jakikolwiek gracz jest w promieniu 100 metrów od aktualnej pozycji VIPa
    conditionCodeSuccess = "!((allPlayers inAreaArray [getPos VIP, 100, 100, 0, false]) isEqualTo [])";
    
    onSuccessEvents[] = { "VIPFound" };
};

//Zabicie celu - wszystko jasne
class KillVIP {
    title = "Zabij VIPA";
    icon = "attack";
    parentTask = "FindVIP";

    // Trzeci z 3 sposobów ustawiania znacznika zadania na mapie.
    // Znacznik będzie podążać za wskazanym obiektem.
    object = "VIP";

    conditionEventsShow[] = { "VIPFound" };
    conditionEventsShowRequired = 1;
    
    // Sprawdzenie czy obiekt "VIP" nie żyje
    conditionCodeSuccess = "!(alive VIP)";
    // Kod powodujący niezaliczenie zadania. Sprawdza czy obiekt "unit1" nie żyje
    conditionCodeFailed = "!(alive unit1)";

    onSuccessEvents[] = { "Killed" };
    onFailedEvents[] = { "playerDied" };
};

// Detonacja - analogiczna sytuacja jak w przypadku ludzi. Również operator "alive" działa
class Kaboom {
    title = "Wysadź wieżę";
    description = "Bomby";
    icon = "destroy";
    parentTask = "Main";
    
    object = "Tower";
    
    // Brak conditionCodeShow ani conditionEventsShow, zadanie będzie widoczne od początku

    conditionCodeSuccess = "!(alive Tower)";
    
    onSuccessEvents[] = { "Boom" };
};

//Czyszczenie danego terenu z wrogów. Opiera się na triggerze z gry który określa przewagę strony w danym obszarze. 
class CityControl {
    title = "Zajmij obszar";
    parentTask = "Main"
    
    marker = "miasto";
    
    // Event jest wywoływany z triggera w grze
    conditionEventsSuccess[] = { "Controlled" };
};
